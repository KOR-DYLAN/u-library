#ifndef __AUTO_CONF_H__
#define __AUTO_CONF_H__

#ifndef DEBUG
#define DEBUG
#endif /* !DEBUG */

#ifndef _DEBUG
#define _DEBUG
#endif /* !_DEBUG */

#endif /* !__AUTO_CONF_H__ */
