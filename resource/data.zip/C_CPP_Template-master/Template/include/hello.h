#ifndef __HELLO__H__
#define __HELLO__H__


#ifdef __cplusplus
extern "C"
{
#endif
    void hello(void);
#ifdef __cplusplus
}
#endif

#endif  //!__HELLO__H__
