#include <iostream>
#include "hello.h"
using namespace std;

int main(void)
{
    cout << "Hello C++ ~!" << endl;
    hello();

    return 0;
}
