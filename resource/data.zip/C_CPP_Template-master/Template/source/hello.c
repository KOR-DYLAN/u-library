#include <stdio.h>
#include "hello.h"

void hello(void)
{
    printf("Hello C World!\n");
}
